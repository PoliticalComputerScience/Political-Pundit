# Assignment Due 10/26

## Another great week y'all.  You guys are basically done LEARNING how to use the Alexa platform (YAY!).  Now, it's time to start development!

Last week, we looked at who was gonna take on which Alexa intents: https://docs.google.com/a/berkeley.edu/document/d/1LpppSxifOsVWQDBM14ePPlkXVAhNd1xILLnPJjGzdbo/edit?usp=sharing

Please sign up for an intent (multiple people should sign up for the "What’s going on in my Gov right now?" intent).

Your assignment is to implement one of the intents.  For example, you could sign up "Bills that were passed in the past 24 hours"). Please write your name next to your intent (no 2 people should do the same intent!) on the Google Doc.

If you sign up for any APIs, please paste your key in this spreadsheet: https://drive.google.com/open?id=1H_gub3OP5MS9Ajmxn7bjmMWPs6NtTneZYXuvab4YluU

To get started, I recommend just looking at the sample.js file!  Essentially, you just have to switch out google api for a different API (and of course, learn how to access the information from the API).
